echo "We are trying this practical from linux EC2"
echo "We are from batch-33 and learning git/gihub"
echo "We are learning Branching"
echo "I am learning Git"
